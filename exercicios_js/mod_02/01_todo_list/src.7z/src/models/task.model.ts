export default interface Task {
  //Atributs
    id: number;
    title: string;
    status: boolean;
    dueDate: Date;
    description?: string

    // Methods
    changeStatus?: (id: number) => void
  }